﻿namespace Group_35_Assignment
{
    partial class frmRcptnEditPrf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlRcptnEditPrf = new System.Windows.Forms.Panel();
            this.lblRcptnEditPrf = new System.Windows.Forms.Label();
            this.pnlRcptnEditDets = new System.Windows.Forms.Panel();
            this.btnRcptnEditPrfBack = new System.Windows.Forms.Button();
            this.btnRcptnEditPrfSave = new System.Windows.Forms.Button();
            this.chkRcptnEditConf = new System.Windows.Forms.CheckBox();
            this.txtRcptnEditReNewPwd = new System.Windows.Forms.TextBox();
            this.txtRcptnEditNewPwd = new System.Windows.Forms.TextBox();
            this.txtRcptnEditOldPwd = new System.Windows.Forms.TextBox();
            this.lblRcptnEditNewPwdTag = new System.Windows.Forms.Label();
            this.lblRcptnEditOldPwdTag = new System.Windows.Forms.Label();
            this.lblRcptnEditUsnmSh = new System.Windows.Forms.Label();
            this.lblRcptnEditUsnmTag = new System.Windows.Forms.Label();
            this.pnlRcptnEditPrf.SuspendLayout();
            this.pnlRcptnEditDets.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlRcptnEditPrf
            // 
            this.pnlRcptnEditPrf.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(163)))), ((int)(((byte)(161)))));
            this.pnlRcptnEditPrf.Controls.Add(this.lblRcptnEditPrf);
            this.pnlRcptnEditPrf.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlRcptnEditPrf.Location = new System.Drawing.Point(0, 0);
            this.pnlRcptnEditPrf.Name = "pnlRcptnEditPrf";
            this.pnlRcptnEditPrf.Size = new System.Drawing.Size(334, 112);
            this.pnlRcptnEditPrf.TabIndex = 0;
            // 
            // lblRcptnEditPrf
            // 
            this.lblRcptnEditPrf.AutoSize = true;
            this.lblRcptnEditPrf.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnEditPrf.ForeColor = System.Drawing.Color.White;
            this.lblRcptnEditPrf.Location = new System.Drawing.Point(31, 18);
            this.lblRcptnEditPrf.Name = "lblRcptnEditPrf";
            this.lblRcptnEditPrf.Size = new System.Drawing.Size(248, 78);
            this.lblRcptnEditPrf.TabIndex = 0;
            this.lblRcptnEditPrf.Text = "Edit Receptionist \r\nProfile";
            // 
            // pnlRcptnEditDets
            // 
            this.pnlRcptnEditDets.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlRcptnEditDets.Controls.Add(this.btnRcptnEditPrfBack);
            this.pnlRcptnEditDets.Controls.Add(this.btnRcptnEditPrfSave);
            this.pnlRcptnEditDets.Controls.Add(this.chkRcptnEditConf);
            this.pnlRcptnEditDets.Controls.Add(this.txtRcptnEditReNewPwd);
            this.pnlRcptnEditDets.Controls.Add(this.txtRcptnEditNewPwd);
            this.pnlRcptnEditDets.Controls.Add(this.txtRcptnEditOldPwd);
            this.pnlRcptnEditDets.Controls.Add(this.lblRcptnEditNewPwdTag);
            this.pnlRcptnEditDets.Controls.Add(this.lblRcptnEditOldPwdTag);
            this.pnlRcptnEditDets.Controls.Add(this.lblRcptnEditUsnmSh);
            this.pnlRcptnEditDets.Controls.Add(this.lblRcptnEditUsnmTag);
            this.pnlRcptnEditDets.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlRcptnEditDets.Location = new System.Drawing.Point(0, 112);
            this.pnlRcptnEditDets.Name = "pnlRcptnEditDets";
            this.pnlRcptnEditDets.Size = new System.Drawing.Size(334, 399);
            this.pnlRcptnEditDets.TabIndex = 1;
            // 
            // btnRcptnEditPrfBack
            // 
            this.btnRcptnEditPrfBack.BackColor = System.Drawing.Color.DarkGray;
            this.btnRcptnEditPrfBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRcptnEditPrfBack.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRcptnEditPrfBack.ForeColor = System.Drawing.Color.White;
            this.btnRcptnEditPrfBack.Location = new System.Drawing.Point(193, 328);
            this.btnRcptnEditPrfBack.Name = "btnRcptnEditPrfBack";
            this.btnRcptnEditPrfBack.Size = new System.Drawing.Size(105, 40);
            this.btnRcptnEditPrfBack.TabIndex = 9;
            this.btnRcptnEditPrfBack.Text = "Back";
            this.btnRcptnEditPrfBack.UseVisualStyleBackColor = false;
            this.btnRcptnEditPrfBack.Click += new System.EventHandler(this.btnRcptnEditPrfBack_Click);
            // 
            // btnRcptnEditPrfSave
            // 
            this.btnRcptnEditPrfSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(108)))), ((int)(((byte)(107)))));
            this.btnRcptnEditPrfSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRcptnEditPrfSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRcptnEditPrfSave.ForeColor = System.Drawing.Color.White;
            this.btnRcptnEditPrfSave.Location = new System.Drawing.Point(36, 328);
            this.btnRcptnEditPrfSave.Name = "btnRcptnEditPrfSave";
            this.btnRcptnEditPrfSave.Size = new System.Drawing.Size(130, 40);
            this.btnRcptnEditPrfSave.TabIndex = 8;
            this.btnRcptnEditPrfSave.Text = "Save Changes";
            this.btnRcptnEditPrfSave.UseVisualStyleBackColor = false;
            this.btnRcptnEditPrfSave.Click += new System.EventHandler(this.btnRcptnEditPrfSave_Click);
            // 
            // chkRcptnEditConf
            // 
            this.chkRcptnEditConf.AutoSize = true;
            this.chkRcptnEditConf.Font = new System.Drawing.Font("Calibri Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.chkRcptnEditConf.Location = new System.Drawing.Point(46, 285);
            this.chkRcptnEditConf.Name = "chkRcptnEditConf";
            this.chkRcptnEditConf.Size = new System.Drawing.Size(176, 23);
            this.chkRcptnEditConf.TabIndex = 7;
            this.chkRcptnEditConf.Text = "Confirm changes made";
            this.chkRcptnEditConf.UseVisualStyleBackColor = true;
            this.chkRcptnEditConf.CheckedChanged += new System.EventHandler(this.chkRcptnEditConf_CheckedChanged);
            // 
            // txtRcptnEditReNewPwd
            // 
            this.txtRcptnEditReNewPwd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtRcptnEditReNewPwd.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtRcptnEditReNewPwd.ForeColor = System.Drawing.Color.Gray;
            this.txtRcptnEditReNewPwd.Location = new System.Drawing.Point(36, 247);
            this.txtRcptnEditReNewPwd.Name = "txtRcptnEditReNewPwd";
            this.txtRcptnEditReNewPwd.Size = new System.Drawing.Size(220, 31);
            this.txtRcptnEditReNewPwd.TabIndex = 6;
            this.txtRcptnEditReNewPwd.Text = "Re-type New Password";
            this.txtRcptnEditReNewPwd.Enter += new System.EventHandler(this.txtRcptnEditReNewPwd_Enter);
            this.txtRcptnEditReNewPwd.Leave += new System.EventHandler(this.txtRcptnEditReNewPwd_Leave);
            // 
            // txtRcptnEditNewPwd
            // 
            this.txtRcptnEditNewPwd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtRcptnEditNewPwd.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtRcptnEditNewPwd.ForeColor = System.Drawing.Color.Gray;
            this.txtRcptnEditNewPwd.Location = new System.Drawing.Point(36, 202);
            this.txtRcptnEditNewPwd.Name = "txtRcptnEditNewPwd";
            this.txtRcptnEditNewPwd.Size = new System.Drawing.Size(220, 31);
            this.txtRcptnEditNewPwd.TabIndex = 5;
            this.txtRcptnEditNewPwd.Text = "New Password";
            this.txtRcptnEditNewPwd.Enter += new System.EventHandler(this.txtRcptnEditNewPwd_Enter);
            this.txtRcptnEditNewPwd.Leave += new System.EventHandler(this.txtRcptnEditNewPwd_Leave);
            // 
            // txtRcptnEditOldPwd
            // 
            this.txtRcptnEditOldPwd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtRcptnEditOldPwd.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtRcptnEditOldPwd.ForeColor = System.Drawing.Color.Gray;
            this.txtRcptnEditOldPwd.Location = new System.Drawing.Point(36, 124);
            this.txtRcptnEditOldPwd.Name = "txtRcptnEditOldPwd";
            this.txtRcptnEditOldPwd.Size = new System.Drawing.Size(220, 31);
            this.txtRcptnEditOldPwd.TabIndex = 4;
            this.txtRcptnEditOldPwd.Text = "Old Password";
            this.txtRcptnEditOldPwd.Enter += new System.EventHandler(this.txtRcptnEditOldPwd_Enter);
            this.txtRcptnEditOldPwd.Leave += new System.EventHandler(this.txtRcptnEditOldPwd_Leave);
            // 
            // lblRcptnEditNewPwdTag
            // 
            this.lblRcptnEditNewPwdTag.AutoSize = true;
            this.lblRcptnEditNewPwdTag.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnEditNewPwdTag.Location = new System.Drawing.Point(31, 168);
            this.lblRcptnEditNewPwdTag.Name = "lblRcptnEditNewPwdTag";
            this.lblRcptnEditNewPwdTag.Size = new System.Drawing.Size(146, 26);
            this.lblRcptnEditNewPwdTag.TabIndex = 3;
            this.lblRcptnEditNewPwdTag.Text = "New Password:";
            // 
            // lblRcptnEditOldPwdTag
            // 
            this.lblRcptnEditOldPwdTag.AutoSize = true;
            this.lblRcptnEditOldPwdTag.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnEditOldPwdTag.Location = new System.Drawing.Point(31, 91);
            this.lblRcptnEditOldPwdTag.Name = "lblRcptnEditOldPwdTag";
            this.lblRcptnEditOldPwdTag.Size = new System.Drawing.Size(135, 26);
            this.lblRcptnEditOldPwdTag.TabIndex = 2;
            this.lblRcptnEditOldPwdTag.Text = "Old Password:";
            // 
            // lblRcptnEditUsnmSh
            // 
            this.lblRcptnEditUsnmSh.AutoSize = true;
            this.lblRcptnEditUsnmSh.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRcptnEditUsnmSh.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnEditUsnmSh.Location = new System.Drawing.Point(36, 55);
            this.lblRcptnEditUsnmSh.Name = "lblRcptnEditUsnmSh";
            this.lblRcptnEditUsnmSh.Size = new System.Drawing.Size(2, 25);
            this.lblRcptnEditUsnmSh.TabIndex = 1;
            // 
            // lblRcptnEditUsnmTag
            // 
            this.lblRcptnEditUsnmTag.AutoSize = true;
            this.lblRcptnEditUsnmTag.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnEditUsnmTag.Location = new System.Drawing.Point(31, 21);
            this.lblRcptnEditUsnmTag.Name = "lblRcptnEditUsnmTag";
            this.lblRcptnEditUsnmTag.Size = new System.Drawing.Size(107, 26);
            this.lblRcptnEditUsnmTag.TabIndex = 0;
            this.lblRcptnEditUsnmTag.Text = "Username:";
            // 
            // frmRcptnEditPrf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 511);
            this.Controls.Add(this.pnlRcptnEditDets);
            this.Controls.Add(this.pnlRcptnEditPrf);
            this.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmRcptnEditPrf";
            this.Text = "Edit Receptionist Profile";
            this.Load += new System.EventHandler(this.frmRcptnEditPrf_Load);
            this.pnlRcptnEditPrf.ResumeLayout(false);
            this.pnlRcptnEditPrf.PerformLayout();
            this.pnlRcptnEditDets.ResumeLayout(false);
            this.pnlRcptnEditDets.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel pnlRcptnEditPrf;
        private Label lblRcptnEditPrf;
        private Panel pnlRcptnEditDets;
        private Button btnRcptnEditPrfBack;
        private Button btnRcptnEditPrfSave;
        private CheckBox chkRcptnEditConf;
        private TextBox txtRcptnEditReNewPwd;
        private TextBox txtRcptnEditNewPwd;
        private TextBox txtRcptnEditOldPwd;
        private Label lblRcptnEditNewPwdTag;
        private Label lblRcptnEditOldPwdTag;
        private Label lblRcptnEditUsnmSh;
        private Label lblRcptnEditUsnmTag;
    }
}