﻿namespace Group_35_Assignment
{
    partial class frmRcptnOfflRec
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlRcptnOfflRec = new System.Windows.Forms.Panel();
            this.picRcptnRecLogo = new System.Windows.Forms.PictureBox();
            this.lblRcptnRecTitle = new System.Windows.Forms.Label();
            this.pnlRcptnRecDets = new System.Windows.Forms.Panel();
            this.lblRcptnRecRcptnUsnm = new System.Windows.Forms.Label();
            this.lblRcptnRecDate = new System.Windows.Forms.Label();
            this.lblRcptnRecNo = new System.Windows.Forms.Label();
            this.lblRcptnRecBalDue = new System.Windows.Forms.Label();
            this.lblRcptnRecSerFee = new System.Windows.Forms.Label();
            this.lblRcptnRecSerType = new System.Windows.Forms.Label();
            this.lblRcptnRecAmtRcvd = new System.Windows.Forms.Label();
            this.lblRcptnRecCustUsnm = new System.Windows.Forms.Label();
            this.lblRcptnRecRcptnUsnmTag = new System.Windows.Forms.Label();
            this.lblRcptnRecDateTag = new System.Windows.Forms.Label();
            this.lblRcptnRecNoTag = new System.Windows.Forms.Label();
            this.lblRcptnRecBalDueTag = new System.Windows.Forms.Label();
            this.lblRcptnRecSerFeeTag = new System.Windows.Forms.Label();
            this.lblRcptnRecSerTypeTag = new System.Windows.Forms.Label();
            this.lblRcptnRecAmtRcvdTag = new System.Windows.Forms.Label();
            this.lblRcptnRecCustUsnmTag = new System.Windows.Forms.Label();
            this.pnlRcptnRecBack = new System.Windows.Forms.Panel();
            this.lblRcptnRecBack = new System.Windows.Forms.Button();
            this.pnlRcptnOfflRec.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRcptnRecLogo)).BeginInit();
            this.pnlRcptnRecDets.SuspendLayout();
            this.pnlRcptnRecBack.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlRcptnOfflRec
            // 
            this.pnlRcptnOfflRec.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(163)))), ((int)(((byte)(161)))));
            this.pnlRcptnOfflRec.Controls.Add(this.picRcptnRecLogo);
            this.pnlRcptnOfflRec.Controls.Add(this.lblRcptnRecTitle);
            this.pnlRcptnOfflRec.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlRcptnOfflRec.Location = new System.Drawing.Point(0, 0);
            this.pnlRcptnOfflRec.Name = "pnlRcptnOfflRec";
            this.pnlRcptnOfflRec.Size = new System.Drawing.Size(784, 114);
            this.pnlRcptnOfflRec.TabIndex = 1;
            // 
            // picRcptnRecLogo
            // 
            this.picRcptnRecLogo.Image = global::Group_35_Assignment.Properties.Resources.Logo;
            this.picRcptnRecLogo.Location = new System.Drawing.Point(643, 8);
            this.picRcptnRecLogo.Name = "picRcptnRecLogo";
            this.picRcptnRecLogo.Size = new System.Drawing.Size(124, 103);
            this.picRcptnRecLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picRcptnRecLogo.TabIndex = 1;
            this.picRcptnRecLogo.TabStop = false;
            // 
            // lblRcptnRecTitle
            // 
            this.lblRcptnRecTitle.AutoSize = true;
            this.lblRcptnRecTitle.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecTitle.ForeColor = System.Drawing.Color.White;
            this.lblRcptnRecTitle.Location = new System.Drawing.Point(19, 37);
            this.lblRcptnRecTitle.Name = "lblRcptnRecTitle";
            this.lblRcptnRecTitle.Size = new System.Drawing.Size(217, 39);
            this.lblRcptnRecTitle.TabIndex = 0;
            this.lblRcptnRecTitle.Text = "Official Receipt";
            // 
            // pnlRcptnRecDets
            // 
            this.pnlRcptnRecDets.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlRcptnRecDets.Controls.Add(this.lblRcptnRecRcptnUsnm);
            this.pnlRcptnRecDets.Controls.Add(this.lblRcptnRecDate);
            this.pnlRcptnRecDets.Controls.Add(this.lblRcptnRecNo);
            this.pnlRcptnRecDets.Controls.Add(this.lblRcptnRecBalDue);
            this.pnlRcptnRecDets.Controls.Add(this.lblRcptnRecSerFee);
            this.pnlRcptnRecDets.Controls.Add(this.lblRcptnRecSerType);
            this.pnlRcptnRecDets.Controls.Add(this.lblRcptnRecAmtRcvd);
            this.pnlRcptnRecDets.Controls.Add(this.lblRcptnRecCustUsnm);
            this.pnlRcptnRecDets.Controls.Add(this.lblRcptnRecRcptnUsnmTag);
            this.pnlRcptnRecDets.Controls.Add(this.lblRcptnRecDateTag);
            this.pnlRcptnRecDets.Controls.Add(this.lblRcptnRecNoTag);
            this.pnlRcptnRecDets.Controls.Add(this.lblRcptnRecBalDueTag);
            this.pnlRcptnRecDets.Controls.Add(this.lblRcptnRecSerFeeTag);
            this.pnlRcptnRecDets.Controls.Add(this.lblRcptnRecSerTypeTag);
            this.pnlRcptnRecDets.Controls.Add(this.lblRcptnRecAmtRcvdTag);
            this.pnlRcptnRecDets.Controls.Add(this.lblRcptnRecCustUsnmTag);
            this.pnlRcptnRecDets.Location = new System.Drawing.Point(0, 112);
            this.pnlRcptnRecDets.Name = "pnlRcptnRecDets";
            this.pnlRcptnRecDets.Size = new System.Drawing.Size(784, 308);
            this.pnlRcptnRecDets.TabIndex = 2;
            // 
            // lblRcptnRecRcptnUsnm
            // 
            this.lblRcptnRecRcptnUsnm.AutoSize = true;
            this.lblRcptnRecRcptnUsnm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRcptnRecRcptnUsnm.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecRcptnUsnm.Location = new System.Drawing.Point(522, 174);
            this.lblRcptnRecRcptnUsnm.MaximumSize = new System.Drawing.Size(230, 0);
            this.lblRcptnRecRcptnUsnm.Name = "lblRcptnRecRcptnUsnm";
            this.lblRcptnRecRcptnUsnm.Size = new System.Drawing.Size(2, 25);
            this.lblRcptnRecRcptnUsnm.TabIndex = 15;
            // 
            // lblRcptnRecDate
            // 
            this.lblRcptnRecDate.AutoSize = true;
            this.lblRcptnRecDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRcptnRecDate.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecDate.Location = new System.Drawing.Point(618, 81);
            this.lblRcptnRecDate.MaximumSize = new System.Drawing.Size(135, 0);
            this.lblRcptnRecDate.Name = "lblRcptnRecDate";
            this.lblRcptnRecDate.Size = new System.Drawing.Size(2, 25);
            this.lblRcptnRecDate.TabIndex = 14;
            // 
            // lblRcptnRecNo
            // 
            this.lblRcptnRecNo.AutoSize = true;
            this.lblRcptnRecNo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRcptnRecNo.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecNo.Location = new System.Drawing.Point(618, 32);
            this.lblRcptnRecNo.MaximumSize = new System.Drawing.Size(135, 0);
            this.lblRcptnRecNo.Name = "lblRcptnRecNo";
            this.lblRcptnRecNo.Size = new System.Drawing.Size(2, 25);
            this.lblRcptnRecNo.TabIndex = 13;
            // 
            // lblRcptnRecBalDue
            // 
            this.lblRcptnRecBalDue.AutoSize = true;
            this.lblRcptnRecBalDue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRcptnRecBalDue.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecBalDue.Location = new System.Drawing.Point(193, 261);
            this.lblRcptnRecBalDue.MaximumSize = new System.Drawing.Size(290, 0);
            this.lblRcptnRecBalDue.Name = "lblRcptnRecBalDue";
            this.lblRcptnRecBalDue.Size = new System.Drawing.Size(2, 25);
            this.lblRcptnRecBalDue.TabIndex = 12;
            // 
            // lblRcptnRecSerFee
            // 
            this.lblRcptnRecSerFee.AutoSize = true;
            this.lblRcptnRecSerFee.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRcptnRecSerFee.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecSerFee.Location = new System.Drawing.Point(193, 214);
            this.lblRcptnRecSerFee.MaximumSize = new System.Drawing.Size(290, 0);
            this.lblRcptnRecSerFee.Name = "lblRcptnRecSerFee";
            this.lblRcptnRecSerFee.Size = new System.Drawing.Size(2, 25);
            this.lblRcptnRecSerFee.TabIndex = 11;
            // 
            // lblRcptnRecSerType
            // 
            this.lblRcptnRecSerType.AutoSize = true;
            this.lblRcptnRecSerType.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRcptnRecSerType.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecSerType.Location = new System.Drawing.Point(193, 142);
            this.lblRcptnRecSerType.MaximumSize = new System.Drawing.Size(290, 0);
            this.lblRcptnRecSerType.Name = "lblRcptnRecSerType";
            this.lblRcptnRecSerType.Size = new System.Drawing.Size(2, 25);
            this.lblRcptnRecSerType.TabIndex = 10;
            // 
            // lblRcptnRecAmtRcvd
            // 
            this.lblRcptnRecAmtRcvd.AutoSize = true;
            this.lblRcptnRecAmtRcvd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRcptnRecAmtRcvd.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecAmtRcvd.Location = new System.Drawing.Point(193, 100);
            this.lblRcptnRecAmtRcvd.MaximumSize = new System.Drawing.Size(290, 0);
            this.lblRcptnRecAmtRcvd.Name = "lblRcptnRecAmtRcvd";
            this.lblRcptnRecAmtRcvd.Size = new System.Drawing.Size(2, 25);
            this.lblRcptnRecAmtRcvd.TabIndex = 9;
            // 
            // lblRcptnRecCustUsnm
            // 
            this.lblRcptnRecCustUsnm.AutoSize = true;
            this.lblRcptnRecCustUsnm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRcptnRecCustUsnm.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecCustUsnm.Location = new System.Drawing.Point(194, 33);
            this.lblRcptnRecCustUsnm.MaximumSize = new System.Drawing.Size(290, 0);
            this.lblRcptnRecCustUsnm.Name = "lblRcptnRecCustUsnm";
            this.lblRcptnRecCustUsnm.Size = new System.Drawing.Size(2, 25);
            this.lblRcptnRecCustUsnm.TabIndex = 8;
            // 
            // lblRcptnRecRcptnUsnmTag
            // 
            this.lblRcptnRecRcptnUsnmTag.AutoSize = true;
            this.lblRcptnRecRcptnUsnmTag.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecRcptnUsnmTag.Location = new System.Drawing.Point(523, 142);
            this.lblRcptnRecRcptnUsnmTag.Name = "lblRcptnRecRcptnUsnmTag";
            this.lblRcptnRecRcptnUsnmTag.Size = new System.Drawing.Size(89, 23);
            this.lblRcptnRecRcptnUsnmTag.TabIndex = 7;
            this.lblRcptnRecRcptnUsnmTag.Text = "Issued by:";
            // 
            // lblRcptnRecDateTag
            // 
            this.lblRcptnRecDateTag.AutoSize = true;
            this.lblRcptnRecDateTag.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecDateTag.Location = new System.Drawing.Point(559, 81);
            this.lblRcptnRecDateTag.Name = "lblRcptnRecDateTag";
            this.lblRcptnRecDateTag.Size = new System.Drawing.Size(53, 23);
            this.lblRcptnRecDateTag.TabIndex = 6;
            this.lblRcptnRecDateTag.Text = "Date:";
            // 
            // lblRcptnRecNoTag
            // 
            this.lblRcptnRecNoTag.AutoSize = true;
            this.lblRcptnRecNoTag.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecNoTag.Location = new System.Drawing.Point(500, 32);
            this.lblRcptnRecNoTag.Name = "lblRcptnRecNoTag";
            this.lblRcptnRecNoTag.Size = new System.Drawing.Size(112, 23);
            this.lblRcptnRecNoTag.TabIndex = 5;
            this.lblRcptnRecNoTag.Text = "Receipt No. :";
            // 
            // lblRcptnRecBalDueTag
            // 
            this.lblRcptnRecBalDueTag.AutoSize = true;
            this.lblRcptnRecBalDueTag.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecBalDueTag.Location = new System.Drawing.Point(74, 261);
            this.lblRcptnRecBalDueTag.Name = "lblRcptnRecBalDueTag";
            this.lblRcptnRecBalDueTag.Size = new System.Drawing.Size(113, 23);
            this.lblRcptnRecBalDueTag.TabIndex = 4;
            this.lblRcptnRecBalDueTag.Text = "Balance Due:";
            // 
            // lblRcptnRecSerFeeTag
            // 
            this.lblRcptnRecSerFeeTag.AutoSize = true;
            this.lblRcptnRecSerFeeTag.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecSerFeeTag.Location = new System.Drawing.Point(39, 214);
            this.lblRcptnRecSerFeeTag.Name = "lblRcptnRecSerFeeTag";
            this.lblRcptnRecSerFeeTag.Size = new System.Drawing.Size(148, 23);
            this.lblRcptnRecSerFeeTag.TabIndex = 3;
            this.lblRcptnRecSerFeeTag.Text = "Total Service Fee:";
            // 
            // lblRcptnRecSerTypeTag
            // 
            this.lblRcptnRecSerTypeTag.AutoSize = true;
            this.lblRcptnRecSerTypeTag.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecSerTypeTag.Location = new System.Drawing.Point(72, 142);
            this.lblRcptnRecSerTypeTag.Name = "lblRcptnRecSerTypeTag";
            this.lblRcptnRecSerTypeTag.Size = new System.Drawing.Size(115, 23);
            this.lblRcptnRecSerTypeTag.TabIndex = 2;
            this.lblRcptnRecSerTypeTag.Text = "Payment For:";
            // 
            // lblRcptnRecAmtRcvdTag
            // 
            this.lblRcptnRecAmtRcvdTag.AutoSize = true;
            this.lblRcptnRecAmtRcvdTag.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecAmtRcvdTag.Location = new System.Drawing.Point(31, 100);
            this.lblRcptnRecAmtRcvdTag.Name = "lblRcptnRecAmtRcvdTag";
            this.lblRcptnRecAmtRcvdTag.Size = new System.Drawing.Size(156, 23);
            this.lblRcptnRecAmtRcvdTag.TabIndex = 1;
            this.lblRcptnRecAmtRcvdTag.Text = "Amount Received:";
            // 
            // lblRcptnRecCustUsnmTag
            // 
            this.lblRcptnRecCustUsnmTag.AutoSize = true;
            this.lblRcptnRecCustUsnmTag.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecCustUsnmTag.Location = new System.Drawing.Point(57, 32);
            this.lblRcptnRecCustUsnmTag.Name = "lblRcptnRecCustUsnmTag";
            this.lblRcptnRecCustUsnmTag.Size = new System.Drawing.Size(130, 23);
            this.lblRcptnRecCustUsnmTag.TabIndex = 0;
            this.lblRcptnRecCustUsnmTag.Text = "Received from:";
            // 
            // pnlRcptnRecBack
            // 
            this.pnlRcptnRecBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pnlRcptnRecBack.Controls.Add(this.lblRcptnRecBack);
            this.pnlRcptnRecBack.Location = new System.Drawing.Point(0, 419);
            this.pnlRcptnRecBack.Name = "pnlRcptnRecBack";
            this.pnlRcptnRecBack.Size = new System.Drawing.Size(784, 74);
            this.pnlRcptnRecBack.TabIndex = 3;
            // 
            // lblRcptnRecBack
            // 
            this.lblRcptnRecBack.BackColor = System.Drawing.Color.DarkGray;
            this.lblRcptnRecBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblRcptnRecBack.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnRecBack.ForeColor = System.Drawing.Color.White;
            this.lblRcptnRecBack.Location = new System.Drawing.Point(643, 19);
            this.lblRcptnRecBack.Name = "lblRcptnRecBack";
            this.lblRcptnRecBack.Size = new System.Drawing.Size(100, 40);
            this.lblRcptnRecBack.TabIndex = 0;
            this.lblRcptnRecBack.Text = "Back";
            this.lblRcptnRecBack.UseVisualStyleBackColor = false;
            this.lblRcptnRecBack.Click += new System.EventHandler(this.lblRcptnRecBack_Click);
            // 
            // frmRcptnOfflRec
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 491);
            this.Controls.Add(this.pnlRcptnRecBack);
            this.Controls.Add(this.pnlRcptnRecDets);
            this.Controls.Add(this.pnlRcptnOfflRec);
            this.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmRcptnOfflRec";
            this.Text = "Official Receipt";
            this.Load += new System.EventHandler(this.frmRcptnOfflRec_Load);
            this.pnlRcptnOfflRec.ResumeLayout(false);
            this.pnlRcptnOfflRec.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRcptnRecLogo)).EndInit();
            this.pnlRcptnRecDets.ResumeLayout(false);
            this.pnlRcptnRecDets.PerformLayout();
            this.pnlRcptnRecBack.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Panel pnlRcptnOfflRec;
        private Label lblRcptnRecTitle;
        private Panel pnlRcptnRecDets;
        private Panel pnlRcptnRecBack;
        private Label lblRcptnRecCustUsnmTag;
        private Label lblRcptnRecCustUsnm;
        private Label lblRcptnRecRcptnUsnmTag;
        private Label lblRcptnRecDateTag;
        private Label lblRcptnRecNoTag;
        private Label lblRcptnRecBalDueTag;
        private Label lblRcptnRecSerFeeTag;
        private Label lblRcptnRecSerTypeTag;
        private Label lblRcptnRecAmtRcvdTag;
        private Label lblRcptnRecBalDue;
        private Label lblRcptnRecSerFee;
        private Label lblRcptnRecSerType;
        private Label lblRcptnRecAmtRcvd;
        private Button lblRcptnRecBack;
        private Label lblRcptnRecRcptnUsnm;
        private Label lblRcptnRecDate;
        private Label lblRcptnRecNo;
        private PictureBox picRcptnRecLogo;
    }
}