﻿namespace Group_35_Assignment
{
    partial class frmRcptnPage
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlRcptnTitle = new System.Windows.Forms.Panel();
            this.btnRcptnLogout = new System.Windows.Forms.Button();
            this.btnRcptnEditPrf = new System.Windows.Forms.Button();
            this.lblRcptnPg = new System.Windows.Forms.Label();
            this.lblRcptnDetsUsnmSh = new System.Windows.Forms.Label();
            this.lblRcptnUsnmTag = new System.Windows.Forms.Label();
            this.pnlRcptnCustReg = new System.Windows.Forms.Panel();
            this.btnRcptnRegCust = new System.Windows.Forms.Button();
            this.chkRcptnShPwd = new System.Windows.Forms.CheckBox();
            this.txtRcptnRegCustPwd = new System.Windows.Forms.TextBox();
            this.txtRcptnRegCustUsnm = new System.Windows.Forms.TextBox();
            this.lblRcptnCustPwdTag = new System.Windows.Forms.Label();
            this.lblRcptnCustUsnmTag = new System.Windows.Forms.Label();
            this.lblRcptnCustReg = new System.Windows.Forms.Label();
            this.btnRcptnPymtPg = new System.Windows.Forms.Button();
            this.pnlRcptnSer = new System.Windows.Forms.Panel();
            this.cboRcptnCustUsnm = new System.Windows.Forms.ComboBox();
            this.lblRcptnCustUsnmCboTag = new System.Windows.Forms.Label();
            this.cboRcptnSerType = new System.Windows.Forms.ComboBox();
            this.radRcptnUrgSer = new System.Windows.Forms.RadioButton();
            this.radRcptnNormSer = new System.Windows.Forms.RadioButton();
            this.btnRcptnClear = new System.Windows.Forms.Button();
            this.btnRcptnCreCust = new System.Windows.Forms.Button();
            this.lblRcptnSerFeeSh = new System.Windows.Forms.Label();
            this.lblRcptnSerFeeTag = new System.Windows.Forms.Label();
            this.lblRcptnSerMes = new System.Windows.Forms.Label();
            this.lblRcptnTosTag = new System.Windows.Forms.Label();
            this.pnlRcptnTitle.SuspendLayout();
            this.pnlRcptnCustReg.SuspendLayout();
            this.pnlRcptnSer.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlRcptnTitle
            // 
            this.pnlRcptnTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(92)))), ((int)(((byte)(107)))));
            this.pnlRcptnTitle.Controls.Add(this.btnRcptnLogout);
            this.pnlRcptnTitle.Controls.Add(this.btnRcptnEditPrf);
            this.pnlRcptnTitle.Controls.Add(this.lblRcptnPg);
            this.pnlRcptnTitle.Controls.Add(this.lblRcptnDetsUsnmSh);
            this.pnlRcptnTitle.Controls.Add(this.lblRcptnUsnmTag);
            this.pnlRcptnTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlRcptnTitle.Location = new System.Drawing.Point(0, 0);
            this.pnlRcptnTitle.Name = "pnlRcptnTitle";
            this.pnlRcptnTitle.Size = new System.Drawing.Size(784, 153);
            this.pnlRcptnTitle.TabIndex = 0;
            // 
            // btnRcptnLogout
            // 
            this.btnRcptnLogout.BackColor = System.Drawing.Color.DarkGray;
            this.btnRcptnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRcptnLogout.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRcptnLogout.ForeColor = System.Drawing.Color.White;
            this.btnRcptnLogout.Location = new System.Drawing.Point(511, 101);
            this.btnRcptnLogout.Name = "btnRcptnLogout";
            this.btnRcptnLogout.Size = new System.Drawing.Size(157, 30);
            this.btnRcptnLogout.TabIndex = 1;
            this.btnRcptnLogout.Text = "Logout";
            this.btnRcptnLogout.UseVisualStyleBackColor = false;
            this.btnRcptnLogout.Click += new System.EventHandler(this.btnRcptnLogout_Click);
            // 
            // btnRcptnEditPrf
            // 
            this.btnRcptnEditPrf.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(163)))), ((int)(((byte)(161)))));
            this.btnRcptnEditPrf.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRcptnEditPrf.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRcptnEditPrf.ForeColor = System.Drawing.Color.White;
            this.btnRcptnEditPrf.Location = new System.Drawing.Point(511, 65);
            this.btnRcptnEditPrf.Name = "btnRcptnEditPrf";
            this.btnRcptnEditPrf.Size = new System.Drawing.Size(157, 30);
            this.btnRcptnEditPrf.TabIndex = 3;
            this.btnRcptnEditPrf.Text = "Edit Profile";
            this.btnRcptnEditPrf.UseVisualStyleBackColor = false;
            this.btnRcptnEditPrf.Click += new System.EventHandler(this.btnRcptnEditPrf_Click);
            // 
            // lblRcptnPg
            // 
            this.lblRcptnPg.AutoSize = true;
            this.lblRcptnPg.Font = new System.Drawing.Font("Calibri", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnPg.ForeColor = System.Drawing.Color.White;
            this.lblRcptnPg.Location = new System.Drawing.Point(30, 52);
            this.lblRcptnPg.Name = "lblRcptnPg";
            this.lblRcptnPg.Size = new System.Drawing.Size(294, 45);
            this.lblRcptnPg.TabIndex = 0;
            this.lblRcptnPg.Text = "Receptionist Page";
            // 
            // lblRcptnDetsUsnmSh
            // 
            this.lblRcptnDetsUsnmSh.AutoSize = true;
            this.lblRcptnDetsUsnmSh.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRcptnDetsUsnmSh.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnDetsUsnmSh.ForeColor = System.Drawing.Color.White;
            this.lblRcptnDetsUsnmSh.Location = new System.Drawing.Point(511, 26);
            this.lblRcptnDetsUsnmSh.Name = "lblRcptnDetsUsnmSh";
            this.lblRcptnDetsUsnmSh.Size = new System.Drawing.Size(2, 25);
            this.lblRcptnDetsUsnmSh.TabIndex = 2;
            // 
            // lblRcptnUsnmTag
            // 
            this.lblRcptnUsnmTag.AutoSize = true;
            this.lblRcptnUsnmTag.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnUsnmTag.ForeColor = System.Drawing.Color.White;
            this.lblRcptnUsnmTag.Location = new System.Drawing.Point(401, 24);
            this.lblRcptnUsnmTag.Name = "lblRcptnUsnmTag";
            this.lblRcptnUsnmTag.Size = new System.Drawing.Size(104, 26);
            this.lblRcptnUsnmTag.TabIndex = 1;
            this.lblRcptnUsnmTag.Text = "Username:";
            // 
            // pnlRcptnCustReg
            // 
            this.pnlRcptnCustReg.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlRcptnCustReg.Controls.Add(this.btnRcptnRegCust);
            this.pnlRcptnCustReg.Controls.Add(this.chkRcptnShPwd);
            this.pnlRcptnCustReg.Controls.Add(this.txtRcptnRegCustPwd);
            this.pnlRcptnCustReg.Controls.Add(this.txtRcptnRegCustUsnm);
            this.pnlRcptnCustReg.Controls.Add(this.lblRcptnCustPwdTag);
            this.pnlRcptnCustReg.Controls.Add(this.lblRcptnCustUsnmTag);
            this.pnlRcptnCustReg.Controls.Add(this.lblRcptnCustReg);
            this.pnlRcptnCustReg.Location = new System.Drawing.Point(0, 153);
            this.pnlRcptnCustReg.Name = "pnlRcptnCustReg";
            this.pnlRcptnCustReg.Size = new System.Drawing.Size(326, 378);
            this.pnlRcptnCustReg.TabIndex = 1;
            // 
            // btnRcptnRegCust
            // 
            this.btnRcptnRegCust.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(92)))), ((int)(((byte)(91)))));
            this.btnRcptnRegCust.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRcptnRegCust.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRcptnRegCust.ForeColor = System.Drawing.Color.White;
            this.btnRcptnRegCust.Location = new System.Drawing.Point(37, 302);
            this.btnRcptnRegCust.Name = "btnRcptnRegCust";
            this.btnRcptnRegCust.Size = new System.Drawing.Size(103, 36);
            this.btnRcptnRegCust.TabIndex = 9;
            this.btnRcptnRegCust.Text = "Register";
            this.btnRcptnRegCust.UseVisualStyleBackColor = false;
            this.btnRcptnRegCust.Click += new System.EventHandler(this.btnRcptnRegCust_Click);
            // 
            // chkRcptnShPwd
            // 
            this.chkRcptnShPwd.AutoSize = true;
            this.chkRcptnShPwd.Font = new System.Drawing.Font("Calibri Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.chkRcptnShPwd.Location = new System.Drawing.Point(41, 252);
            this.chkRcptnShPwd.Name = "chkRcptnShPwd";
            this.chkRcptnShPwd.Size = new System.Drawing.Size(126, 23);
            this.chkRcptnShPwd.TabIndex = 4;
            this.chkRcptnShPwd.Text = "Show password";
            this.chkRcptnShPwd.UseVisualStyleBackColor = true;
            this.chkRcptnShPwd.CheckedChanged += new System.EventHandler(this.chkRcptnShPwd_CheckedChanged);
            // 
            // txtRcptnRegCustPwd
            // 
            this.txtRcptnRegCustPwd.BackColor = System.Drawing.Color.LightGray;
            this.txtRcptnRegCustPwd.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtRcptnRegCustPwd.ForeColor = System.Drawing.Color.Gray;
            this.txtRcptnRegCustPwd.Location = new System.Drawing.Point(37, 207);
            this.txtRcptnRegCustPwd.Name = "txtRcptnRegCustPwd";
            this.txtRcptnRegCustPwd.Size = new System.Drawing.Size(216, 33);
            this.txtRcptnRegCustPwd.TabIndex = 3;
            this.txtRcptnRegCustPwd.Text = "Password";
            this.txtRcptnRegCustPwd.Enter += new System.EventHandler(this.txtRcptnRegCustPwd_Enter);
            this.txtRcptnRegCustPwd.Leave += new System.EventHandler(this.txtRcptnRegCustPwd_Leave);
            // 
            // txtRcptnRegCustUsnm
            // 
            this.txtRcptnRegCustUsnm.BackColor = System.Drawing.Color.LightGray;
            this.txtRcptnRegCustUsnm.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtRcptnRegCustUsnm.ForeColor = System.Drawing.Color.Gray;
            this.txtRcptnRegCustUsnm.Location = new System.Drawing.Point(37, 111);
            this.txtRcptnRegCustUsnm.Name = "txtRcptnRegCustUsnm";
            this.txtRcptnRegCustUsnm.Size = new System.Drawing.Size(216, 33);
            this.txtRcptnRegCustUsnm.TabIndex = 3;
            this.txtRcptnRegCustUsnm.Text = "Username";
            this.txtRcptnRegCustUsnm.Enter += new System.EventHandler(this.txtRcptnRegCustUsnm_Enter);
            this.txtRcptnRegCustUsnm.Leave += new System.EventHandler(this.txtRcptnRegCustUsnm_Leave);
            // 
            // lblRcptnCustPwdTag
            // 
            this.lblRcptnCustPwdTag.AutoSize = true;
            this.lblRcptnCustPwdTag.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnCustPwdTag.Location = new System.Drawing.Point(33, 163);
            this.lblRcptnCustPwdTag.Name = "lblRcptnCustPwdTag";
            this.lblRcptnCustPwdTag.Size = new System.Drawing.Size(159, 26);
            this.lblRcptnCustPwdTag.TabIndex = 2;
            this.lblRcptnCustPwdTag.Text = "Create Password:";
            // 
            // lblRcptnCustUsnmTag
            // 
            this.lblRcptnCustUsnmTag.AutoSize = true;
            this.lblRcptnCustUsnmTag.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnCustUsnmTag.Location = new System.Drawing.Point(33, 68);
            this.lblRcptnCustUsnmTag.Name = "lblRcptnCustUsnmTag";
            this.lblRcptnCustUsnmTag.Size = new System.Drawing.Size(164, 26);
            this.lblRcptnCustUsnmTag.TabIndex = 1;
            this.lblRcptnCustUsnmTag.Text = "Create Username:";
            // 
            // lblRcptnCustReg
            // 
            this.lblRcptnCustReg.AutoSize = true;
            this.lblRcptnCustReg.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnCustReg.Location = new System.Drawing.Point(30, 23);
            this.lblRcptnCustReg.Name = "lblRcptnCustReg";
            this.lblRcptnCustReg.Size = new System.Drawing.Size(266, 33);
            this.lblRcptnCustReg.TabIndex = 0;
            this.lblRcptnCustReg.Text = "Customer Registration";
            // 
            // btnRcptnPymtPg
            // 
            this.btnRcptnPymtPg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(108)))), ((int)(((byte)(107)))));
            this.btnRcptnPymtPg.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRcptnPymtPg.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRcptnPymtPg.ForeColor = System.Drawing.Color.White;
            this.btnRcptnPymtPg.Location = new System.Drawing.Point(277, 306);
            this.btnRcptnPymtPg.Name = "btnRcptnPymtPg";
            this.btnRcptnPymtPg.Size = new System.Drawing.Size(152, 43);
            this.btnRcptnPymtPg.TabIndex = 0;
            this.btnRcptnPymtPg.Text = "Payment Page";
            this.btnRcptnPymtPg.UseVisualStyleBackColor = false;
            this.btnRcptnPymtPg.Click += new System.EventHandler(this.btnRcptnPymtPg_Click);
            // 
            // pnlRcptnSer
            // 
            this.pnlRcptnSer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(157)))), ((int)(((byte)(179)))));
            this.pnlRcptnSer.Controls.Add(this.cboRcptnCustUsnm);
            this.pnlRcptnSer.Controls.Add(this.lblRcptnCustUsnmCboTag);
            this.pnlRcptnSer.Controls.Add(this.cboRcptnSerType);
            this.pnlRcptnSer.Controls.Add(this.btnRcptnPymtPg);
            this.pnlRcptnSer.Controls.Add(this.radRcptnUrgSer);
            this.pnlRcptnSer.Controls.Add(this.radRcptnNormSer);
            this.pnlRcptnSer.Controls.Add(this.btnRcptnClear);
            this.pnlRcptnSer.Controls.Add(this.btnRcptnCreCust);
            this.pnlRcptnSer.Controls.Add(this.lblRcptnSerFeeSh);
            this.pnlRcptnSer.Controls.Add(this.lblRcptnSerFeeTag);
            this.pnlRcptnSer.Controls.Add(this.lblRcptnSerMes);
            this.pnlRcptnSer.Controls.Add(this.lblRcptnTosTag);
            this.pnlRcptnSer.Location = new System.Drawing.Point(325, 153);
            this.pnlRcptnSer.Name = "pnlRcptnSer";
            this.pnlRcptnSer.Size = new System.Drawing.Size(459, 378);
            this.pnlRcptnSer.TabIndex = 4;
            // 
            // cboRcptnCustUsnm
            // 
            this.cboRcptnCustUsnm.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cboRcptnCustUsnm.FormattingEnabled = true;
            this.cboRcptnCustUsnm.Location = new System.Drawing.Point(43, 68);
            this.cboRcptnCustUsnm.Name = "cboRcptnCustUsnm";
            this.cboRcptnCustUsnm.Size = new System.Drawing.Size(359, 31);
            this.cboRcptnCustUsnm.TabIndex = 10;
            this.cboRcptnCustUsnm.Text = "Customer Username";
            this.cboRcptnCustUsnm.SelectedIndexChanged += new System.EventHandler(this.cboRcptnCustUsnm_SelectedIndexChanged);
            // 
            // lblRcptnCustUsnmCboTag
            // 
            this.lblRcptnCustUsnmCboTag.AutoSize = true;
            this.lblRcptnCustUsnmCboTag.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnCustUsnmCboTag.ForeColor = System.Drawing.Color.White;
            this.lblRcptnCustUsnmCboTag.Location = new System.Drawing.Point(33, 23);
            this.lblRcptnCustUsnmCboTag.Name = "lblRcptnCustUsnmCboTag";
            this.lblRcptnCustUsnmCboTag.Size = new System.Drawing.Size(253, 33);
            this.lblRcptnCustUsnmCboTag.TabIndex = 9;
            this.lblRcptnCustUsnmCboTag.Text = "Customer Username:";
            // 
            // cboRcptnSerType
            // 
            this.cboRcptnSerType.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cboRcptnSerType.FormattingEnabled = true;
            this.cboRcptnSerType.Items.AddRange(new object[] {
            "Remove virus, malware or spyware",
            "Troubleshot and fix computer running slow",
            "Laptop screen replacement",
            "Laptop keyboard replacement",
            "Laptop battery replacement",
            "Operating System Format and Installation",
            "Data backup and recovery",
            "Internet connectivity issues"});
            this.cboRcptnSerType.Location = new System.Drawing.Point(43, 158);
            this.cboRcptnSerType.Name = "cboRcptnSerType";
            this.cboRcptnSerType.Size = new System.Drawing.Size(359, 31);
            this.cboRcptnSerType.TabIndex = 8;
            this.cboRcptnSerType.Text = "Service Type";
            this.cboRcptnSerType.SelectedIndexChanged += new System.EventHandler(this.cboRcptnSerType_SelectedIndexChanged);
            // 
            // radRcptnUrgSer
            // 
            this.radRcptnUrgSer.AutoSize = true;
            this.radRcptnUrgSer.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.radRcptnUrgSer.ForeColor = System.Drawing.Color.White;
            this.radRcptnUrgSer.Location = new System.Drawing.Point(214, 201);
            this.radRcptnUrgSer.Name = "radRcptnUrgSer";
            this.radRcptnUrgSer.Size = new System.Drawing.Size(71, 23);
            this.radRcptnUrgSer.TabIndex = 7;
            this.radRcptnUrgSer.TabStop = true;
            this.radRcptnUrgSer.Text = "Urgent";
            this.radRcptnUrgSer.UseVisualStyleBackColor = true;
            this.radRcptnUrgSer.CheckedChanged += new System.EventHandler(this.radRcptnUrgSer_CheckedChanged);
            // 
            // radRcptnNormSer
            // 
            this.radRcptnNormSer.AutoSize = true;
            this.radRcptnNormSer.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.radRcptnNormSer.ForeColor = System.Drawing.Color.White;
            this.radRcptnNormSer.Location = new System.Drawing.Point(52, 201);
            this.radRcptnNormSer.Name = "radRcptnNormSer";
            this.radRcptnNormSer.Size = new System.Drawing.Size(74, 23);
            this.radRcptnNormSer.TabIndex = 6;
            this.radRcptnNormSer.TabStop = true;
            this.radRcptnNormSer.Text = "Normal";
            this.radRcptnNormSer.UseVisualStyleBackColor = true;
            this.radRcptnNormSer.CheckedChanged += new System.EventHandler(this.radRcptnNormSer_CheckedChanged);
            // 
            // btnRcptnClear
            // 
            this.btnRcptnClear.BackColor = System.Drawing.Color.DarkGray;
            this.btnRcptnClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRcptnClear.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRcptnClear.ForeColor = System.Drawing.Color.White;
            this.btnRcptnClear.Location = new System.Drawing.Point(299, 262);
            this.btnRcptnClear.Name = "btnRcptnClear";
            this.btnRcptnClear.Size = new System.Drawing.Size(103, 36);
            this.btnRcptnClear.TabIndex = 5;
            this.btnRcptnClear.Text = "Clear";
            this.btnRcptnClear.UseVisualStyleBackColor = false;
            this.btnRcptnClear.Click += new System.EventHandler(this.btnRcptnClear_Click);
            // 
            // btnRcptnCreCust
            // 
            this.btnRcptnCreCust.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(92)))), ((int)(((byte)(91)))));
            this.btnRcptnCreCust.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRcptnCreCust.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRcptnCreCust.ForeColor = System.Drawing.Color.White;
            this.btnRcptnCreCust.Location = new System.Drawing.Point(299, 218);
            this.btnRcptnCreCust.Name = "btnRcptnCreCust";
            this.btnRcptnCreCust.Size = new System.Drawing.Size(103, 36);
            this.btnRcptnCreCust.TabIndex = 4;
            this.btnRcptnCreCust.Text = "Create";
            this.btnRcptnCreCust.UseVisualStyleBackColor = false;
            this.btnRcptnCreCust.Click += new System.EventHandler(this.btnRcptnCreCust_Click);
            // 
            // lblRcptnSerFeeSh
            // 
            this.lblRcptnSerFeeSh.AutoSize = true;
            this.lblRcptnSerFeeSh.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRcptnSerFeeSh.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnSerFeeSh.Location = new System.Drawing.Point(43, 307);
            this.lblRcptnSerFeeSh.Name = "lblRcptnSerFeeSh";
            this.lblRcptnSerFeeSh.Size = new System.Drawing.Size(2, 28);
            this.lblRcptnSerFeeSh.TabIndex = 3;
            // 
            // lblRcptnSerFeeTag
            // 
            this.lblRcptnSerFeeTag.AutoSize = true;
            this.lblRcptnSerFeeTag.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnSerFeeTag.ForeColor = System.Drawing.Color.White;
            this.lblRcptnSerFeeTag.Location = new System.Drawing.Point(33, 263);
            this.lblRcptnSerFeeTag.Name = "lblRcptnSerFeeTag";
            this.lblRcptnSerFeeTag.Size = new System.Drawing.Size(142, 33);
            this.lblRcptnSerFeeTag.TabIndex = 2;
            this.lblRcptnSerFeeTag.Text = "Service Fee:";
            // 
            // lblRcptnSerMes
            // 
            this.lblRcptnSerMes.AutoSize = true;
            this.lblRcptnSerMes.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnSerMes.Location = new System.Drawing.Point(52, 231);
            this.lblRcptnSerMes.Name = "lblRcptnSerMes";
            this.lblRcptnSerMes.Size = new System.Drawing.Size(206, 15);
            this.lblRcptnSerMes.TabIndex = 1;
            this.lblRcptnSerMes.Text = "*Urgent services are more expensive";
            // 
            // lblRcptnTosTag
            // 
            this.lblRcptnTosTag.AutoSize = true;
            this.lblRcptnTosTag.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnTosTag.ForeColor = System.Drawing.Color.White;
            this.lblRcptnTosTag.Location = new System.Drawing.Point(33, 113);
            this.lblRcptnTosTag.Name = "lblRcptnTosTag";
            this.lblRcptnTosTag.Size = new System.Drawing.Size(369, 33);
            this.lblRcptnTosTag.TabIndex = 0;
            this.lblRcptnTosTag.Text = "Choose type of Service needed:";
            // 
            // frmRcptnPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 531);
            this.Controls.Add(this.pnlRcptnSer);
            this.Controls.Add(this.pnlRcptnCustReg);
            this.Controls.Add(this.pnlRcptnTitle);
            this.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmRcptnPage";
            this.Text = "Receptionist Page";
            this.Load += new System.EventHandler(this.frmRcptnPage_Load);
            this.pnlRcptnTitle.ResumeLayout(false);
            this.pnlRcptnTitle.PerformLayout();
            this.pnlRcptnCustReg.ResumeLayout(false);
            this.pnlRcptnCustReg.PerformLayout();
            this.pnlRcptnSer.ResumeLayout(false);
            this.pnlRcptnSer.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel pnlRcptnTitle;
        private Label lblRcptnPg;
        private Panel pnlRcptnCustReg;
        private Label lblRcptnCustPwdTag;
        private Label lblRcptnCustUsnmTag;
        private Label lblRcptnCustReg;
        private Panel pnlRcptnSer;
        private Label lblRcptnSerFeeSh;
        private Label lblRcptnSerFeeTag;
        private Label lblRcptnSerMes;
        private Label lblRcptnTosTag;
        private CheckBox chkRcptnShPwd;
        private TextBox txtRcptnRegCustPwd;
        private TextBox txtRcptnRegCustUsnm;
        private Button btnRcptnPymtPg;
        private ComboBox cboRcptnSerType;
        private RadioButton radRcptnUrgSer;
        private RadioButton radRcptnNormSer;
        private Button btnRcptnClear;
        private Button btnRcptnCreCust;
        private Button btnRcptnLogout;
        private Button btnRcptnEditPrf;
        private Label lblRcptnDetsUsnmSh;
        private Label lblRcptnUsnmTag;
        private Button btnRcptnRegCust;
        private ComboBox cboRcptnCustUsnm;
        private Label lblRcptnCustUsnmCboTag;
    }
}