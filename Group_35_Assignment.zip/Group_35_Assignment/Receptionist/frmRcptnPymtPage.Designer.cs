﻿namespace Group_35_Assignment
{
    partial class frmRcptnPymtPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlRcptnPymt = new System.Windows.Forms.Panel();
            this.lblRcptnPymt = new System.Windows.Forms.Label();
            this.pnlRcptnPymtDets = new System.Windows.Forms.Panel();
            this.btnRcptnPymtClear = new System.Windows.Forms.Button();
            this.cboRcptnPymtCustUsnm = new System.Windows.Forms.ComboBox();
            this.lblRcptnPymtRcvdRM = new System.Windows.Forms.Label();
            this.txtRcptnPymtRcvd = new System.Windows.Forms.TextBox();
            this.lblRcptnPymtRcvdTag = new System.Windows.Forms.Label();
            this.btnRcptnPymtBack = new System.Windows.Forms.Button();
            this.btnRcptnPymtGenRcpt = new System.Windows.Forms.Button();
            this.btnRcptnPymtAcc = new System.Windows.Forms.Button();
            this.lblRcptnPymtSerFeeSh = new System.Windows.Forms.Label();
            this.lblRcptnPymtSerFeeTag = new System.Windows.Forms.Label();
            this.lblRcptnPymtSerSh = new System.Windows.Forms.Label();
            this.lblRcptnPymtSerTypTag = new System.Windows.Forms.Label();
            this.lblRcptnPymtCustUsnmTag = new System.Windows.Forms.Label();
            this.pnlRcptnPymt.SuspendLayout();
            this.pnlRcptnPymtDets.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlRcptnPymt
            // 
            this.pnlRcptnPymt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(108)))), ((int)(((byte)(107)))));
            this.pnlRcptnPymt.Controls.Add(this.lblRcptnPymt);
            this.pnlRcptnPymt.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlRcptnPymt.Location = new System.Drawing.Point(0, 0);
            this.pnlRcptnPymt.Name = "pnlRcptnPymt";
            this.pnlRcptnPymt.Size = new System.Drawing.Size(384, 96);
            this.pnlRcptnPymt.TabIndex = 0;
            // 
            // lblRcptnPymt
            // 
            this.lblRcptnPymt.AutoSize = true;
            this.lblRcptnPymt.Font = new System.Drawing.Font("Calibri", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnPymt.ForeColor = System.Drawing.Color.White;
            this.lblRcptnPymt.Location = new System.Drawing.Point(24, 25);
            this.lblRcptnPymt.Name = "lblRcptnPymt";
            this.lblRcptnPymt.Size = new System.Drawing.Size(168, 49);
            this.lblRcptnPymt.TabIndex = 0;
            this.lblRcptnPymt.Text = "Payment";
            // 
            // pnlRcptnPymtDets
            // 
            this.pnlRcptnPymtDets.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlRcptnPymtDets.Controls.Add(this.btnRcptnPymtClear);
            this.pnlRcptnPymtDets.Controls.Add(this.cboRcptnPymtCustUsnm);
            this.pnlRcptnPymtDets.Controls.Add(this.lblRcptnPymtRcvdRM);
            this.pnlRcptnPymtDets.Controls.Add(this.txtRcptnPymtRcvd);
            this.pnlRcptnPymtDets.Controls.Add(this.lblRcptnPymtRcvdTag);
            this.pnlRcptnPymtDets.Controls.Add(this.btnRcptnPymtBack);
            this.pnlRcptnPymtDets.Controls.Add(this.btnRcptnPymtGenRcpt);
            this.pnlRcptnPymtDets.Controls.Add(this.btnRcptnPymtAcc);
            this.pnlRcptnPymtDets.Controls.Add(this.lblRcptnPymtSerFeeSh);
            this.pnlRcptnPymtDets.Controls.Add(this.lblRcptnPymtSerFeeTag);
            this.pnlRcptnPymtDets.Controls.Add(this.lblRcptnPymtSerSh);
            this.pnlRcptnPymtDets.Controls.Add(this.lblRcptnPymtSerTypTag);
            this.pnlRcptnPymtDets.Controls.Add(this.lblRcptnPymtCustUsnmTag);
            this.pnlRcptnPymtDets.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlRcptnPymtDets.Location = new System.Drawing.Point(0, 95);
            this.pnlRcptnPymtDets.Name = "pnlRcptnPymtDets";
            this.pnlRcptnPymtDets.Size = new System.Drawing.Size(384, 446);
            this.pnlRcptnPymtDets.TabIndex = 1;
            // 
            // btnRcptnPymtClear
            // 
            this.btnRcptnPymtClear.BackColor = System.Drawing.Color.DarkGray;
            this.btnRcptnPymtClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRcptnPymtClear.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRcptnPymtClear.ForeColor = System.Drawing.Color.White;
            this.btnRcptnPymtClear.Location = new System.Drawing.Point(278, 68);
            this.btnRcptnPymtClear.Name = "btnRcptnPymtClear";
            this.btnRcptnPymtClear.Size = new System.Drawing.Size(74, 36);
            this.btnRcptnPymtClear.TabIndex = 14;
            this.btnRcptnPymtClear.Text = "Clear";
            this.btnRcptnPymtClear.UseVisualStyleBackColor = false;
            this.btnRcptnPymtClear.Click += new System.EventHandler(this.btnRcptnPymtClear_Click);
            // 
            // cboRcptnPymtCustUsnm
            // 
            this.cboRcptnPymtCustUsnm.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cboRcptnPymtCustUsnm.FormattingEnabled = true;
            this.cboRcptnPymtCustUsnm.Location = new System.Drawing.Point(31, 72);
            this.cboRcptnPymtCustUsnm.Name = "cboRcptnPymtCustUsnm";
            this.cboRcptnPymtCustUsnm.Size = new System.Drawing.Size(224, 31);
            this.cboRcptnPymtCustUsnm.TabIndex = 13;
            this.cboRcptnPymtCustUsnm.Text = "Customer Username";
            this.cboRcptnPymtCustUsnm.SelectedIndexChanged += new System.EventHandler(this.cboRcptnPymtCustUsnm_SelectedIndexChanged);
            // 
            // lblRcptnPymtRcvdRM
            // 
            this.lblRcptnPymtRcvdRM.AutoSize = true;
            this.lblRcptnPymtRcvdRM.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnPymtRcvdRM.Location = new System.Drawing.Point(31, 324);
            this.lblRcptnPymtRcvdRM.Name = "lblRcptnPymtRcvdRM";
            this.lblRcptnPymtRcvdRM.Size = new System.Drawing.Size(38, 23);
            this.lblRcptnPymtRcvdRM.TabIndex = 12;
            this.lblRcptnPymtRcvdRM.Text = "RM";
            // 
            // txtRcptnPymtRcvd
            // 
            this.txtRcptnPymtRcvd.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtRcptnPymtRcvd.Location = new System.Drawing.Point(75, 321);
            this.txtRcptnPymtRcvd.Name = "txtRcptnPymtRcvd";
            this.txtRcptnPymtRcvd.Size = new System.Drawing.Size(107, 31);
            this.txtRcptnPymtRcvd.TabIndex = 11;
            // 
            // lblRcptnPymtRcvdTag
            // 
            this.lblRcptnPymtRcvdTag.AutoSize = true;
            this.lblRcptnPymtRcvdTag.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnPymtRcvdTag.Location = new System.Drawing.Point(31, 274);
            this.lblRcptnPymtRcvdTag.Name = "lblRcptnPymtRcvdTag";
            this.lblRcptnPymtRcvdTag.Size = new System.Drawing.Size(224, 26);
            this.lblRcptnPymtRcvdTag.TabIndex = 10;
            this.lblRcptnPymtRcvdTag.Text = "Enter Amount Received:";
            // 
            // btnRcptnPymtBack
            // 
            this.btnRcptnPymtBack.BackColor = System.Drawing.Color.DarkGray;
            this.btnRcptnPymtBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRcptnPymtBack.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRcptnPymtBack.ForeColor = System.Drawing.Color.White;
            this.btnRcptnPymtBack.Location = new System.Drawing.Point(262, 382);
            this.btnRcptnPymtBack.Name = "btnRcptnPymtBack";
            this.btnRcptnPymtBack.Size = new System.Drawing.Size(90, 34);
            this.btnRcptnPymtBack.TabIndex = 9;
            this.btnRcptnPymtBack.Text = "Back";
            this.btnRcptnPymtBack.UseVisualStyleBackColor = false;
            this.btnRcptnPymtBack.Click += new System.EventHandler(this.btnRcptnPymtBack_Click);
            // 
            // btnRcptnPymtGenRcpt
            // 
            this.btnRcptnPymtGenRcpt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnRcptnPymtGenRcpt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRcptnPymtGenRcpt.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRcptnPymtGenRcpt.ForeColor = System.Drawing.Color.White;
            this.btnRcptnPymtGenRcpt.Location = new System.Drawing.Point(28, 382);
            this.btnRcptnPymtGenRcpt.Name = "btnRcptnPymtGenRcpt";
            this.btnRcptnPymtGenRcpt.Size = new System.Drawing.Size(154, 36);
            this.btnRcptnPymtGenRcpt.TabIndex = 8;
            this.btnRcptnPymtGenRcpt.Text = "Generate Receipt";
            this.btnRcptnPymtGenRcpt.UseVisualStyleBackColor = false;
            this.btnRcptnPymtGenRcpt.Click += new System.EventHandler(this.btnRcptnPymtGenRcpt_Click);
            // 
            // btnRcptnPymtAcc
            // 
            this.btnRcptnPymtAcc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(163)))), ((int)(((byte)(161)))));
            this.btnRcptnPymtAcc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRcptnPymtAcc.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRcptnPymtAcc.ForeColor = System.Drawing.Color.White;
            this.btnRcptnPymtAcc.Location = new System.Drawing.Point(198, 320);
            this.btnRcptnPymtAcc.Name = "btnRcptnPymtAcc";
            this.btnRcptnPymtAcc.Size = new System.Drawing.Size(154, 36);
            this.btnRcptnPymtAcc.TabIndex = 7;
            this.btnRcptnPymtAcc.Text = "Accept Payment";
            this.btnRcptnPymtAcc.UseVisualStyleBackColor = false;
            this.btnRcptnPymtAcc.Click += new System.EventHandler(this.btnRcptnPymtAcc_Click);
            // 
            // lblRcptnPymtSerFeeSh
            // 
            this.lblRcptnPymtSerFeeSh.AutoSize = true;
            this.lblRcptnPymtSerFeeSh.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRcptnPymtSerFeeSh.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnPymtSerFeeSh.Location = new System.Drawing.Point(31, 233);
            this.lblRcptnPymtSerFeeSh.Name = "lblRcptnPymtSerFeeSh";
            this.lblRcptnPymtSerFeeSh.Size = new System.Drawing.Size(2, 25);
            this.lblRcptnPymtSerFeeSh.TabIndex = 4;
            // 
            // lblRcptnPymtSerFeeTag
            // 
            this.lblRcptnPymtSerFeeTag.AutoSize = true;
            this.lblRcptnPymtSerFeeTag.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnPymtSerFeeTag.Location = new System.Drawing.Point(28, 195);
            this.lblRcptnPymtSerFeeTag.Name = "lblRcptnPymtSerFeeTag";
            this.lblRcptnPymtSerFeeTag.Size = new System.Drawing.Size(118, 26);
            this.lblRcptnPymtSerFeeTag.TabIndex = 3;
            this.lblRcptnPymtSerFeeTag.Text = "Service Fee:";
            // 
            // lblRcptnPymtSerSh
            // 
            this.lblRcptnPymtSerSh.AutoSize = true;
            this.lblRcptnPymtSerSh.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRcptnPymtSerSh.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnPymtSerSh.Location = new System.Drawing.Point(31, 159);
            this.lblRcptnPymtSerSh.Name = "lblRcptnPymtSerSh";
            this.lblRcptnPymtSerSh.Size = new System.Drawing.Size(2, 20);
            this.lblRcptnPymtSerSh.TabIndex = 2;
            // 
            // lblRcptnPymtSerTypTag
            // 
            this.lblRcptnPymtSerTypTag.AutoSize = true;
            this.lblRcptnPymtSerTypTag.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnPymtSerTypTag.Location = new System.Drawing.Point(28, 121);
            this.lblRcptnPymtSerTypTag.Name = "lblRcptnPymtSerTypTag";
            this.lblRcptnPymtSerTypTag.Size = new System.Drawing.Size(127, 26);
            this.lblRcptnPymtSerTypTag.TabIndex = 1;
            this.lblRcptnPymtSerTypTag.Text = "Service Type:";
            // 
            // lblRcptnPymtCustUsnmTag
            // 
            this.lblRcptnPymtCustUsnmTag.AutoSize = true;
            this.lblRcptnPymtCustUsnmTag.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRcptnPymtCustUsnmTag.Location = new System.Drawing.Point(28, 30);
            this.lblRcptnPymtCustUsnmTag.Name = "lblRcptnPymtCustUsnmTag";
            this.lblRcptnPymtCustUsnmTag.Size = new System.Drawing.Size(208, 26);
            this.lblRcptnPymtCustUsnmTag.TabIndex = 0;
            this.lblRcptnPymtCustUsnmTag.Text = "Customer\'s Username:";
            // 
            // frmRcptnPymtPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 541);
            this.Controls.Add(this.pnlRcptnPymtDets);
            this.Controls.Add(this.pnlRcptnPymt);
            this.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Name = "frmRcptnPymtPage";
            this.Text = "frmRcptnPymtPage";
            this.Load += new System.EventHandler(this.frmRcptnPymtPage_Load);
            this.pnlRcptnPymt.ResumeLayout(false);
            this.pnlRcptnPymt.PerformLayout();
            this.pnlRcptnPymtDets.ResumeLayout(false);
            this.pnlRcptnPymtDets.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel pnlRcptnPymt;
        private Panel pnlRcptnPymtDets;
        private Label lblRcptnPymt;
        private Button btnRcptnPymtBack;
        private Button btnRcptnPymtGenRcpt;
        private Button btnRcptnPymtAcc;
        private Label lblRcptnPymtSerFeeSh;
        private Label lblRcptnPymtSerFeeTag;
        private Label lblRcptnPymtSerSh;
        private Label lblRcptnPymtSerTypTag;
        private Label lblRcptnPymtCustUsnmTag;
        private Label lblRcptnPymtRcvdTag;
        private Label lblRcptnPymtRcvdRM;
        private TextBox txtRcptnPymtRcvd;
        private ComboBox cboRcptnPymtCustUsnm;
        private Button btnRcptnPymtClear;
    }
}